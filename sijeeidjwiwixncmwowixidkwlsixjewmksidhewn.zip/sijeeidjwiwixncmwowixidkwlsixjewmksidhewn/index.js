require('dotenv').config();
const { Client, GatewayIntentBits, Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Partials } = require('discord.js');

// ضع هنا آي دي حسابك الشخصي (رقم فقط)
const OWNER_ID = '1277322156690247720';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel, Partials.Message, Partials.User]
});

const IMAGE_URL = 'https://cdn.discordapp.com/attachments/1423755997146513430/1423829673669820527/B1DEEAA1-3D0A-4EEA-BE0D-9C23D489A726.jpg?ex=68e1bc37&is=68e06ab7&hm=dc94416300ae2a67d5c4bf4fb5a4b427d9ad907ee5003db60a2c0cb683891456&';

const PRODUCTS = [
  { id: 'prod1', name:  'نيترو', price: 30000, link: 'https://vencord.dev' },
  { id: 'prod2', name: 'هاك ديسكورد', price: 15000, link: 'https://vencord.dev' },
  { id: 'prod3', name: 'نسخ سيرفرات', price: 10000, link: 'افتح تكت' },
  { id: 'prod4', name: 'بروجكت بيع تلقاىي', price: 150000, link: 'https://example.com/item4' },
  { id: 'prod5', name: 'تهكير سيرفرات ديسكورد', price: 40000, link: 'افتح تكت' },
  { id: 'prod6', name: 'منتج 6', price: 350, link: 'https://example.com/item6' },
  { id: 'prod7', name: 'منتج 7', price: 400, link: 'https://example.com/item7' },
  { id: 'prod8', name: 'منتج 8', price: 450, link: 'https://example.com/item8' },
  { id: 'prod9', name: 'منتج 9', price: 500, link: 'https://example.com/item9' },
  { id: 'prod10', name: 'منتج 10', price: 0, link: 'https://example.com/item10' }
];

const CREDIT_USER = '— 𝐀𝐛𝐮 𝐬𝐚𝐮𝐝';
const CREDIT_MESSAGE = (price) => `يرجى تحويل ${price} كريدت إلى ${CREDIT_USER} ثم أرسل صورة إثبات التحويل هنا (في الخاص أو الشات).`;

const awaitingPayment = new Map();
const pendingApprovals = new Map();

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  // أمر -say
  if (message.content.startsWith('-say ')) {
    const text = message.content.slice(5).trim();
    if (text.length > 0) {
      await message.delete();
      await message.channel.send(text);
    }
    return;
  }

  // أمر "خط"
  if (message.content.trim() === 'خط') {
    await message.delete();
    await message.channel.send({ files: [IMAGE_URL] });
    return;
  }

  // أمر -status
  if (message.content.trim() === '-status') {
    const embed = new EmbedBuilder()
      .setColor(0x2F3136)
      .addFields(
        { name: 'STATUS', value: '🟢 Online', inline: false },
        { name: 'F8 CONNECT COMMAND', value: 'connect jdyaz4', inline: false },
        { name: 'NEXT RESTART', value: 'in 3 hrs, 51 mins', inline: false },
        { name: 'UPTIME', value: '46 mins', inline: false },
      );
    await message.channel.send({ embeds: [embed] });
    return;
  }

  // أمر -شراء (عرض المنتجات)
  if (message.content.trim() === '-شراء') {
    let rows = [];
    for (let i = 0; i < PRODUCTS.length; i += 5) {
      rows.push(
        new ActionRowBuilder().addComponents(
          PRODUCTS.slice(i, i + 5).map(prod =>
            new ButtonBuilder()
              .setCustomId(`buy_${prod.id}`)
              .setLabel(`${prod.name} - ${prod.price} كريدت`)
              .setStyle(ButtonStyle.Primary)
          )
        )
      );
    }
    const embed = new EmbedBuilder()
      .setTitle('قائمة المنتجات')
      .setDescription(PRODUCTS.map(p => `**${p.name}** | السعر: ${p.price} كريدت`).join('\n'));
    await message.reply({ embeds: [embed], components: rows });
    return;
  }

  // استقبال صورة التحويل
  if (awaitingPayment.has(message.author.id) && message.attachments.size > 0) {
    const product = awaitingPayment.get(message.author.id);
    const owner = await client.users.fetch(OWNER_ID);
    const attachment = message.attachments.first();
    const approveRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`approve_${message.author.id}_${product.id}`)
        .setLabel('موافقة')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`reject_${message.author.id}_${product.id}`)
        .setLabel('رفض')
        .setStyle(ButtonStyle.Danger)
    );
    await owner.send({
      content: `طلب شراء من <@${message.author.id}> للمنتج: **${product.name}** (${product.price} كريدت)\nرابط المنتج: ${product.link}`,
      files: [attachment.url],
      components: [approveRow]
    });
    pendingApprovals.set(`${message.author.id}_${product.id}`, { user: message.author, product });
    await message.reply('تم إرسال إثبات التحويل للإدارة. سيتم مراجعة طلبك قريباً.');
    return;
  }

  // رسالة إذا لم يرسل صورة بعد الشراء
  if (awaitingPayment.has(message.author.id) && message.attachments.size === 0 && message.content.trim() !== '') {
    await message.reply('يرجى إرسال صورة إثبات التحويل كملف مرفق.');
    return;
  }

  // أمر "كم سعر ..."
  if (
    message.content.trim().startsWith('كم سعر') ||
    message.content.trim().toLowerCase().startsWith('price ')
  ) {
    let query = message.content.replace('كم سعر', '').replace('?', '').trim();
    if (query === '') {
      await message.reply('يرجى كتابة اسم المنتج بعد كلمة "كم سعر".');
      return;
    }
    const found = PRODUCTS.find(
      p =>
        p.name === query ||
        p.name.replace('منتج ', '').trim() === query.replace('منتج ', '').trim() ||
        p.id.toLowerCase() === query.toLowerCase() ||
        p.name.toLowerCase() === query.toLowerCase()
    );
    if (found) {
      await message.reply(`سعر **${found.name}** هو ${found.price} كريدت.`);
    } else {
      await message.reply('المنتج غير موجود. تأكد من كتابة اسم المنتج بشكل صحيح.');
    }
    return;
  }
});

// أزرار الموافقة والرفض والشراء
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isButton()) return;

  // الموافقة/الرفض من صاحب البوت
  if (interaction.user.id === OWNER_ID && (interaction.customId.startsWith('approve_') || interaction.customId.startsWith('reject_'))) {
    const [action, userId, prodId] = interaction.customId.split('_');
    const pending = pendingApprovals.get(`${userId}_${prodId}`);
    if (!pending) {
      await interaction.reply({ content: 'هذا الطلب غير موجود أو تم التعامل معه بالفعل.', ephemeral: true });
      return;
    }
    if (action === 'approve') {
      await pending.user.send(`تمت الموافقة على طلبك!\n**${pending.product.name}**\nرابط المنتج: ${pending.product.link}`);
      await interaction.reply({ content: `تمت الموافقة وتم إرسال المنتج للعميل.`, ephemeral: true });
    } else if (action === 'reject') {
      await pending.user.send(`عذراً، تم رفض طلبك لشراء **${pending.product.name}**.`);
      await interaction.reply({ content: 'تم رفض الطلب.', ephemeral: true });
    }
    pendingApprovals.delete(`${userId}_${prodId}`);
    awaitingPayment.delete(userId);
    return;
  }

  // زر الشراء
  const product = PRODUCTS.find(p => `buy_${p.id}` === interaction.customId);
  if (product) {
    awaitingPayment.set(interaction.user.id, product);
    await interaction.reply({
      content: CREDIT_MESSAGE(product.price) + '\n\nبعد التحويل أرسل صورة الإثبات هنا أو في الخاص.',
      ephemeral: true
    });
  }
});

client.login(process.env.BOT_TOKEN);